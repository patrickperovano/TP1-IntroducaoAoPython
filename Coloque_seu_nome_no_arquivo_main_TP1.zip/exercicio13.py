# Exercício 13
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que calcule a área de um retângulo. Onde você informará o comprimento e a largura. 

# Fórmula: A = c x l 

# Onde: A = Área

# c = comprimento

# l = largura

# Escreva seu código aqui


comprimento = float(input ("Informe o comprimento da base: "))
largura = float(input ("Agora, informe a largura: "))

area = comprimento * largura

print ("A área do retângulo é no tamanho de ", area)