# Exercício 7
# Atribua seu nome e sua comida favorita a 2 variáveis separadas com nomes adequados.
# Emita o conteúdo das variáveis em 2 linhas separadas.

# Atribuição de Variáveis

# Atribua seu nome e sua comida favorita a 2 variáveis separadas com nomes adequados.

nome = "Patrick"
comida = "Pizza"

############# SIMPLES ###################

# Mostra o conteúdo das variáveis em 2 linhas separadas
print (nome)
print (comida)

# Tarefa de extensão 1
# Emita duas frases (não apenas o conteúdo das variáveis). O primeiro com seu nome, o segundo com sua comida favorita.

print ('Meu nome é ', nome,"\nMinha comida favorita é", comida)

############# MÉDIO ####################

# Saída de duas frases (não apenas o conteúdo das variáveis). O primeiro com seu nome, o segundo com sua comida favorita.

print ('Meu nome é ', nome,"\nMinha comida favorita é", comida)

# Tarefa de extensão 2
# Emita ambas as informações como parte da mesma frase. Certifique-se de ter espaços e pontuação nos lugares corretos.

print ('Meu nome é ', nome,". Minha comida favorita é", comida)


############# COMPLEXO ###################

# Emita ambas as informações como parte da mesma frase.

# Certifique-se de ter espaços e pontuação nos lugares corretos.

print ('Meu nome é ', nome,". Minha comida favorita é", comida)


