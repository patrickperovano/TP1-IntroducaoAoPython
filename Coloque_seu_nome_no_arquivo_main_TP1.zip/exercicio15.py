#Exercício 15
# Escreva um código que funcione de acordo com o enunciado

# Três amigos saíram juntos para o cinema. O amigo 1 levou R$100,00. O amigo 2 levou 2 vezes e meia o valor do amigo 1. E o amigo 3 levou a metade do valor somado dos outros dois amigos. 

# Faça um programa que calcule o valor total que os três amigos levaram para o cinema. 

# Escreva seu código aqui