#Exercício 15
# Escreva um código que funcione de acordo com o enunciado

# Três amigos saíram juntos para o cinema. O amigo 1 levou R$100,00. O amigo 2 levou 2 vezes e meia o valor do amigo 1. E o amigo 3 levou a metade do valor somado dos outros dois amigos. 

# Faça um programa que calcule o valor total que os três amigos levaram para o cinema. 

# Escreva seu código aqui

Amigo1 = 100.00
Amigo2 = Amigo1 * 2.5
Amigo3 = (Amigo1 + Amigo2) / 2

print("Cada amigo levo a certa quantidade de dinheiro ao cinema")
print("Amigo 1:", Amigo1)
print("Amigo 2:", Amigo2)
print("Amigo 3:", Amigo3)