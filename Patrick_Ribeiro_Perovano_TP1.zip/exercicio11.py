# Exercício 11
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que somará dois números e mostrará a média desses números como resultado.

# Escreva seu código aqui

numero1 = float(input ("Digite o primeiro número: "))
numero2 = float(input ("Digite o segundo número: "))
avg = (numero1 + numero2) / 2
print ("A média dos dois números é igual a:", avg)