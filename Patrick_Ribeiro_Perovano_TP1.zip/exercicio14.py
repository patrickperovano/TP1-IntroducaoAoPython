# Exercício 14
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que calcule o volume de um paralelepípedo. Onde você informará o comprimento, a largura e a altura. 

# Fórmula: V = c x l x h

# Onde: V = Volume

# c = comprimento

# l = largura

# h = altura

# Escreva seu código aqui#


comprimento = float(input ("Informe o comprimento da base: "))
largura = float(input ("Informe a largura: "))
altura = float(input ("Agora, informe a altura: "))

volume = comprimento * largura * altura

print ("A volume do paralelepípedo é no tamanho de ", volume)