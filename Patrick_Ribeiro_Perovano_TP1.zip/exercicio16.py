# Exercício 16
# Escreva um código que funcione de acordo com o enunciado

# Quatro amigas foram ao shopping comprar roupas. A amiga 1 levou R$240,00. A amiga 2 levou dois terços (2/3) do valor da amiga 1. A amiga 3 levou 3 vezes o valor da amiga 2. A amiga 4 levou o valor somado das amigas 2 e 3.

# Faça um programa que calcule o valor total que as quatro amigas levaram para o shopping. 

# Escreva seu código aqui

Amiga1 = 240.00
Amiga2 = (Amiga1 / 3) * 2
Amiga3 = Amiga2 * 3
Amiga4 = Amiga2 + Amiga3

print("Cada amiga levo a certa quantidade de dinheiro ao shopping")
print("Amiga 1:", Amiga1)
print("Amiga 2:", Amiga2)
print("Amiga 3:", Amiga3)
print("Amiga 4:", Amiga4)